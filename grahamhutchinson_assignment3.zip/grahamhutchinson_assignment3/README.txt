Each of the four deliverables are found in the deliverables folder. The images folder contains each of the images saved that were converted to gif format, if you would like to have a closer look at any of them. The original csv file is althete_events.csv, the rest are parsed data to be visualised. The programs included are each of the programs to parse the data, as well as the python program to run the visualisation. In order to obtain the gif in the deliverables folder,  you would need to run choropleth.py, and then run the follwoing command from the images directory:

convert -delay 100 image*.py olympic.gif

To run this program you need geopandas installed, as well as imagemagick, numpy and matplotlib. 

I have supplied a Google Drive link to my video presentation in the link_to_video_presentation.txt file in the deliverables folder.
